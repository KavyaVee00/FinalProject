package FFINalProject;

interface LinkedListADT<T> {
    void add(T data);
    void remove(T data);
    T get(int index);
}